# LumaOS Launcher — Beta 1.0.0

A standalone Android home-screen launcher prototype inspired by the visual language of Xiaomi HyperOS. It is a launcher app, not a replacement Android operating system or a flashable ROM.

## Features
- Registers as an Android Home app; choose it from the system's Home app picker.
- Displays a LumaOS-branded home screen with a live clock and date.
- Lists installed launcher apps using Android's package manager and their real app icons.
- Opens apps when their icons are tapped.
- Swipe up, tap the search bar, or tap All apps to open the searchable app drawer.
- Settings shortcut opens Android Settings.
- Frosted translucent cards, rounded dock, and a blue-violet gradient background.

## Build on GitHub from your Pixel
1. Create a new GitHub repository, e.g. `LumaOS-Launcher`.
2. Extract this ZIP on your phone and upload the *contents* of this folder to the repository root. Do not upload this ZIP as a single file.
3. Make sure `.github/workflows/build-apk.yml` is included. If Android/GitHub hides dot-folders in the file picker, create the workflow file in GitHub using the exact path `.github/workflows/build-apk.yml` and paste the workflow from this project.
4. Open the repository's **Actions** tab.
5. Select **Build LumaOS Launcher APK** and tap **Run workflow** (or push a change to `main`).
6. When the run succeeds, download the `LumaOS-Launcher-1.0.0-Beta` artifact and extract `app-debug.apk`.

## Install and select as Home
Install the APK, then press the phone's Home gesture/button. Choose **LumaOS Launcher** and select **Always** if you want it as the default home app. You can change it later in Android Settings → Apps → Default apps → Home app.

## Compatibility notes
- `minSdk 26` (Android 8.0+) and `targetSdk 35`; this is a conventional Android app intended to run on current Android versions, including Android 17 where backward-compatible apps are supported. It does not target Android 17's API level specifically.
- The Pixel 7 Pro is supported as a normal Android launcher host. The app does not replace the Pixel firmware, system Settings, notification shade, or Quick Settings.
- This is an early launcher prototype. It does not yet support widgets, icon editing, gesture customization, wallpaper picker integration, or full HyperOS system animations.
