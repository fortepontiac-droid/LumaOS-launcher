package com.luma.launcher

import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : android.app.Activity() {
    private val apps = mutableListOf<ResolveInfo>()
    private lateinit var root: LinearLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private var downY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 18, 39)
        window.navigationBarColor = Color.rgb(13, 18, 39)
        window.decorView.systemUiVisibility = 0
        loadApps()
        buildHome()
        updateTime()
        root.postDelayed(object : Runnable {
            override fun run() {
                if (!isFinishing) {
                    updateTime()
                    root.postDelayed(this, 30_000)
                }
            }
        }, 30_000)
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps.clear()
        apps.addAll(packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) })
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(13, 19, 43), Color.rgb(32, 43, 91), Color.rgb(71, 48, 119), Color.rgb(17, 22, 43)))
        }
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val delta = downY - event.y
                    if (delta > dp(65)) showAppDrawer()
                    true
                }
                else -> true
            }
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text = "LumaOS"; textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(36), 1f))
        val settings = TextView(this).apply { text = "⚙"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setOnClickListener { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        top.addView(settings, LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(top)

        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(5), dp(36), dp(5), dp(22)) }
        clock = TextView(this).apply { textSize = 58f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }
        date = TextView(this).apply { textSize = 15f; setTextColor(0xFFD7DDF7.toInt()) }
        hero.addView(clock)
        hero.addView(date)
        root.addView(hero)

        val search = TextView(this).apply {
            text = "⌕     Search apps"
            textSize = 16f
            setTextColor(0xFFE9EDFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            background = rounded(0x35FFFFFF, 28)
            setOnClickListener { showAppDrawer() }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(26) })

        val section = TextView(this).apply { text = "YOUR APPS"; textSize = 11f; letterSpacing = 0.16f; setTextColor(0xBFFFFFFF.toInt()); setPadding(dp(4), 0, 0, dp(12)) }
        root.addView(section)
        val grid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = false }
        val shown = apps.take(8)
        shown.forEach { grid.addView(appTile(it), GridLayout.LayoutParams().apply { width = 0; height = dp(100); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(2), dp(2), dp(2), dp(8)) }) }
        val all = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setOnClickListener { showAppDrawer() } }
        val allIcon = TextView(this).apply { text = "⠿"; textSize = 31f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(0x44FFFFFF, 22) }
        all.addView(allIcon, LinearLayout.LayoutParams(dp(58), dp(58)))
        all.addView(TextView(this).apply { text = "All apps"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1 }, LinearLayout.LayoutParams(-1, dp(28)))
        grid.addView(all, GridLayout.LayoutParams().apply { width = 0; height = dp(100); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(2), dp(2), dp(2), dp(8)) })
        root.addView(grid)
        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = rounded(0x38FFFFFF, 30)
        }
        val dockApps = apps.filter { info ->
            val n = info.loadLabel(packageManager).toString().lowercase(Locale.getDefault())
            n.contains("phone") || n.contains("camera") || n.contains("chrome") || n.contains("message")
        }.distinctBy { it.activityInfo.packageName }.take(4)
        if (dockApps.isEmpty()) shown.take(4).forEach { dock.addView(dockIcon(it), LinearLayout.LayoutParams(0, dp(64), 1f)) }
        else dockApps.forEach { dock.addView(dockIcon(it), LinearLayout.LayoutParams(0, dp(64), 1f)) }
        root.addView(dock, LinearLayout.LayoutParams(-1, dp(82)))
        val hint = TextView(this).apply { text = "Swipe up for all apps"; textSize = 11f; gravity = Gravity.CENTER; setTextColor(0x99FFFFFF.toInt()); setPadding(0, dp(9), 0, 0) }
        root.addView(hint)
        setContentView(root)
    }

    private fun appTile(info: ResolveInfo): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setOnClickListener { launch(info) } }
        val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)); scaleType = ImageView.ScaleType.FIT_CENTER }
        box.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
        box.addView(TextView(this).apply {
            text = info.loadLabel(packageManager).toString(); textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, dp(27)))
        return box
    }

    private fun dockIcon(info: ResolveInfo): View {
        val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)); scaleType = ImageView.ScaleType.FIT_CENTER; setOnClickListener { launch(info) }; contentDescription = info.loadLabel(packageManager) }
        return icon
    }

    private fun showAppDrawer() {
        loadApps()
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(8)); background = rounded(0xFF202744.toInt(), 26) }
        val title = TextView(this).apply { text = "All apps"; textSize = 23f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        panel.addView(title, LinearLayout.LayoutParams(-1, dp(42)))
        val input = EditText(this).apply {
            hint = "Search apps"; textSize = 15f; singleLine = true; setTextColor(Color.WHITE); setHintTextColor(0xFFB6BED8.toInt())
            background = rounded(0xFF343D5D.toInt(), 20); setPadding(dp(14), 0, dp(14), 0)
        }
        panel.addView(input, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })
        val list = ListView(this).apply { divider = null; isVerticalScrollBarEnabled = true; cacheColorHint = Color.TRANSPARENT }
        val adapter = AppListAdapter(apps.toList())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> launch(adapter.items[position]) }
        panel.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        input.addTextChangedListener(SimpleTextWatcher { query -> adapter.filter(query) })
        val dialog = AlertDialog.Builder(this).setView(panel).create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        list.setOnItemClickListener { _, _, position, _ -> launch(adapter.items[position]); dialog.dismiss() }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), (resources.displayMetrics.heightPixels * 0.78).toInt())
    }

    private inner class AppListAdapter(var items: List<ResolveInfo>) : BaseAdapter() {
        private val allItems = apps.toList()
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(7), dp(8), dp(7)) }
            val icon = ImageView(this@MainActivity).apply { setImageDrawable(getItem(position).loadIcon(packageManager)) }
            row.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
            row.addView(TextView(this@MainActivity).apply { text = getItem(position).loadLabel(packageManager); textSize = 15f; setTextColor(Color.WHITE); setPadding(dp(14), 0, 0, 0) })
            return row
        }
        fun filter(q: String) { items = if (q.isBlank()) allItems else allItems.filter { it.loadLabel(packageManager).toString().contains(q, true) }; notifyDataSetChanged() }
    }

    private fun launch(info: ResolveInfo) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(info.activityInfo.packageName, info.activityInfo.name)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Couldn't open app", Toast.LENGTH_SHORT).show() }
    }

    private fun updateTime() {
        clock.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(Date())
        date.text = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), 0x24FFFFFF) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onResume() { super.onResume(); if (::root.isInitialized) { loadApps(); updateTime() } }
}

private class SimpleTextWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString().orEmpty()) }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
